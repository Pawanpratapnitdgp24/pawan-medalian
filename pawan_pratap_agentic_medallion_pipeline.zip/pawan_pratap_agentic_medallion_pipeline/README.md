# Pawan Pratap — Agentic Medallion Data Pipeline

A clean-room implementation of the same product idea as the referenced public project: turn messy CSV files + a plain-English business question into reviewed Bronze/Silver/Gold datasets and an executive analytics report.

**Author / branding:** Pawan Pratap

> This repository is a new implementation. It does not copy the source code of the referenced repository. The public project was used only as a behavioral/architecture reference.

## What it does

1. Upload one or more CSV files.
2. Describe the business question in plain English.
3. Profile the data and surface nulls, types, cardinality, duplicates, and join candidates.
4. Generate Bronze, Silver, and Gold Source-to-Target Mapping (STTM) proposals.
5. Require a human approval gate before moving to the next layer.
6. Write each medallion layer as Parquet.
7. Run automatic data-quality gates between layers.
8. Build analytics-ready Gold tables, lineage, and metrics.
9. Query Gold with DuckDB and create an HTML executive report with Plotly charts.
10. Keep audit logs, run state, metrics, STTM version history, and lightweight semantic memory.
11. Support optional LLM-powered profiling, mapping, SQL, reports, and follow-up questions.

## Architecture

```text
                  +---------------------------+
                  |     Streamlit UI / API    |
                  +-------------+-------------+
                                |
                                v
                     +--------------------+
                     |    Orchestrator    |
                     |  HITL checkpoints  |
                     +----+----+----+----+
                          |    |    |
              +-----------+    |    +-------------+
              v                v                  v
          Profiler         STTM Generator       Reporter
              |                |                  |
              v                v                  v
          Bronze Agent -> Silver Agent -> Gold Agent
              |                |                  |
              +----------------+------------------+
                               |
                               v
                    Parquet + DuckDB + Audit
```

## Repository layout

```text
pawan-pratap-agentic-medallion-pipeline/
├── app/streamlit_app.py
├── agents/
│   ├── __init__.py
│   ├── llm_client.py
│   ├── profiler.py
│   ├── sttm_generator.py
│   ├── bronze_agent.py
│   ├── silver_agent.py
│   ├── gold_agent.py
│   ├── reporter.py
│   └── orchestrator.py
├── core/
│   ├── __init__.py
│   ├── config.py
│   ├── audit.py
│   ├── cache.py
│   ├── custom_transforms.py
│   ├── data_quality.py
│   ├── exceptions.py
│   ├── lineage.py
│   ├── memory.py
│   ├── metrics.py
│   ├── notifications.py
│   ├── observability.py
│   ├── retry.py
│   ├── run_store.py
│   ├── state.py
│   └── sttm_versioning.py
├── sample_data/
├── data/
├── reports/
├── audit_logs/
├── tests/
├── api.py
├── pyproject.toml
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
├── .env.example
└── .github/workflows/ci.yml
```

## LLM providers

The app works without an API key using deterministic heuristics, which makes the GitHub repository immediately demoable. For AI-assisted generation, set `LLM_PROVIDER` and its matching secret in `.env`.

Supported providers in the implementation:

- `openai`
- `groq`
- `github`
- `anthropic`
- `gemini`

The implementation uses HTTP directly for provider calls so the runtime has fewer moving pieces than a large agent-framework dependency tree.

## Local setup

### Windows PowerShell

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
streamlit run app/streamlit_app.py
```

### macOS / Linux

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
streamlit run app/streamlit_app.py
```

Open `http://localhost:8501`.

## GitHub + Streamlit Community Cloud

1. Create a new GitHub repository, for example `pawan-pratap-agentic-medallion-pipeline`.
2. Upload this complete folder, including `app/`, `agents/`, `core/`, `data/`, `sample_data/`, and `tests/`.
3. In Streamlit Community Cloud, choose the repository and set the entrypoint to `app/streamlit_app.py`.
4. Add secrets/environment variables from `.env.example` in the deployment settings.
5. Deploy.

For a public demo without paid AI, you can leave all provider keys blank; the heuristic mode still profiles CSVs, builds STTM, executes the layers, and creates a report.

## Docker

```bash
cp .env.example .env
# Add a provider key if desired
docker compose up --build
```

The UI is exposed on `http://localhost:8501`.

## CLI

Run the full workflow without Streamlit:

```bash
python run_pipeline_cli.py --files sample_data/sales_data.csv sample_data/products.csv sample_data/stores.csv --question "Which regions and categories drive revenue?"
```

## API

The same pipeline can be driven with FastAPI:

```bash
uvicorn api:app --host 0.0.0.0 --port 8000
```

Then:

```bash
curl http://localhost:8000/health
```

The endpoint `POST /runs` accepts multipart `files` and `business_intent`.

## Optional PostgreSQL export

Gold Parquet files can also be exported to PostgreSQL using `postgres_export.export_gold_files(...)` with a SQLAlchemy DSN. Set `DATABASE_URL` and `POSTGRES_SCHEMA` in `.env` when this capability is required.

## Data quality

A score is calculated per output table using completeness, duplicate rate, and basic schema health. `QUALITY_MIN_SCORE_TO_PASS` controls the minimum score. `QUALITY_FAIL_ON_LOW_SCORE=true` makes a failed gate stop the pipeline.

## Security notes

- `.env` is ignored by Git.
- API keys are read only from environment variables.
- Generated runtime data is ignored except for the sample landing files.
- Custom expressions use an AST whitelist rather than raw `eval`.
- Follow-up SQL accepts only read-only `SELECT` / `WITH` statements.

## License

MIT. See `LICENSE`.
