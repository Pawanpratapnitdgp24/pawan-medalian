from __future__ import annotations

import html
import json
from pathlib import Path
import streamlit as st
import pandas as pd

from agents.orchestrator import new_run, run_until_bronze_sttm, run_bronze_to_silver_sttm, run_silver_to_gold_sttm, run_gold_and_report
from agents.reporter import answer_followup_question
from admin_dashboard import render_admin_dashboard
from core.audit import AuditLogger
from core.config import APP_NAME, AUTHOR_NAME, LANDING_DIR, MAX_UPLOAD_MB, has_llm
from core.lineage import build_mermaid_diagram
from core.metrics import summarize_run, export_metrics_csv
from core.run_store import load_state

st.set_page_config(page_title=APP_NAME, page_icon="🏗️", layout="wide")

STEPS = [
    ("upload", "Upload & Intent"),
    ("bronze_sttm", "Bronze STTM Review"),
    ("silver_sttm", "Silver STTM Review"),
    ("gold_sttm", "Gold STTM Review"),
    ("report", "Executive Report"),
]


def _banner(state=None):
    current = state.phase if state else "upload"
    idx = next((i for i, item in enumerate(STEPS) if item[0] == current), 0)
    if state and state.status == "completed": idx = len(STEPS)
    cells = []
    for i, (_, label) in enumerate(STEPS):
        cls = "done" if i < idx else "current" if i == idx else "next"
        cells.append(f"<div class='step {cls}'><b>{'✓' if i < idx else i+1}</b><span>{html.escape(label)}</span></div>")
    st.markdown("<style> .pp-title{padding:18px 22px;border-radius:18px;background:linear-gradient(135deg,#111827,#1e3a8a);color:#fff;margin-bottom:18px}.steps{display:flex;gap:8px;overflow:auto;margin:10px 0 22px}.step{min-width:160px;padding:12px;border:1px solid #dbe3ee;border-radius:12px;background:#fff;display:flex;gap:10px;align-items:center}.step.done{border-color:#10b981}.step.current{border-color:#2563eb;box-shadow:0 0 0 2px #dbeafe}.step b{display:grid;place-items:center;width:26px;height:26px;border-radius:50%;background:#e5e7eb}.step.done b{background:#d1fae5}.step.current b{background:#dbeafe}</style>", unsafe_allow_html=True)
    st.markdown(f"<div class='pp-title'><h1 style='margin:0'>🏗️ {html.escape(APP_NAME)}</h1><p style='margin:6px 0 0'>Human-in-the-loop AI data engineering • {html.escape(AUTHOR_NAME)}</p></div><div class='steps'>{''.join(cells)}</div>", unsafe_allow_html=True)


def _save_uploaded(uploaded):
    target = LANDING_DIR / Path(uploaded.name).name
    target.write_bytes(uploaded.getvalue())
    return str(target)


def _review_sttm(path: str, label: str):
    st.subheader(label)
    frame = pd.read_csv(path)
    edited = st.data_editor(frame, use_container_width=True, num_rows="dynamic", key=f"editor_{label}")
    if st.button(f"💾 Save {label}", key=f"save_{label}"):
        edited.to_csv(path, index=False)
        st.success("STTM saved.")
    return edited


if "state" not in st.session_state:
    st.session_state.state = None

state = st.session_state.state
_banner(state)

with st.sidebar:
    st.markdown("### Pipeline controls")
    st.caption(f"AI mode: {'LLM enabled' if has_llm() else 'Deterministic demo mode'}")
    if state:
        st.code(state.run_id, language="text")
        if st.button("Reload current run"):
            st.session_state.state = load_state(state.run_id)
            st.rerun()
    st.divider()
    st.markdown("**Deployment-ready**")
    st.caption("Secrets belong in Streamlit Secrets or .env, never in Git.")

if state is None:
    st.header("Start a new pipeline run")
    files = st.file_uploader("Upload CSV files", type=["csv"], accept_multiple_files=True)
    intent = st.text_area("Business question", placeholder="Which regions and product categories drive the most revenue, and where are returns concentrated?")
    if st.button("🚀 Start Workflow", type="primary"):
        if not files or not intent.strip():
            st.error("Upload at least one CSV and enter a business question.")
        else:
            saved = [_save_uploaded(f) for f in files]
            run = new_run(intent.strip(), saved)
            try:
                run_until_bronze_sttm(run)
                st.session_state.state = run
                st.rerun()
            except Exception as exc:
                st.error(str(exc))
    st.info("Tip: `sample_data/` contains ready-to-use sales, products, and stores CSVs.")

elif state.status == "awaiting_bronze_approval":
    st.header("Phase 1 · Review Bronze mapping")
    _review_sttm(state.sttm_bronze_path, "Bronze STTM")
    if st.button("✅ Approve Bronze & Continue", type="primary"):
        state.bronze_sttm_approved = True
        run_bronze_to_silver_sttm(state)
        st.session_state.state = state
        st.rerun()

elif state.status == "awaiting_silver_approval":
    st.header("Phase 2 · Review Silver cleansing")
    st.success(f"Bronze outputs: {len(state.bronze_output_paths)} parquet table(s)")
    _review_sttm(state.sttm_silver_path, "Silver STTM")
    if st.button("✅ Approve Silver & Continue", type="primary"):
        state.silver_sttm_approved = True
        run_silver_to_gold_sttm(state)
        st.session_state.state = state
        st.rerun()

elif state.status == "awaiting_gold_approval":
    st.header("Phase 3 · Review Gold analytics mapping")
    st.success(f"Silver outputs: {len(state.silver_output_paths)} parquet table(s)")
    _review_sttm(state.sttm_gold_path, "Gold STTM")
    if st.button("✅ Approve Gold & Build Report", type="primary"):
        state.gold_sttm_approved = True
        run_gold_and_report(state)
        st.session_state.state = state
        st.rerun()

elif state.status == "completed":
    st.header("Phase 4 · Executive results")
    metric = summarize_run(state.run_id)
    cols = st.columns(4)
    cols[0].metric("Status", "Completed")
    cols[1].metric("Gold tables", len(state.gold_output_paths))
    cols[2].metric("Agent steps", metric["agents"])
    cols[3].metric("Pipeline time (ms)", metric["duration_ms"])
    if Path(state.report_path).exists():
        html_report = Path(state.report_path).read_text(encoding="utf-8")
        st.components.v1.html(html_report, height=900, scrolling=True)
        st.download_button("⬇️ Download HTML report", html_report, file_name=Path(state.report_path).name, mime="text/html")
    st.subheader("Lineage")
    st.code(build_mermaid_diagram(state), language="text")
    st.subheader("Audit trail")
    logs = AuditLogger(state.run_id).get_logs()
    st.dataframe(pd.DataFrame(logs), use_container_width=True)
    st.subheader("Follow-up question")
    question = st.text_input("Ask about the Gold output")
    if st.button("Ask") and question.strip():
        try:
            answer = answer_followup_question(state.gold_output_paths, question, state.run_id, state.business_intent)
            st.write(answer.get("direct_answer", "No answer returned."))
            if answer.get("rows"):
                st.dataframe(pd.DataFrame(answer["rows"]), use_container_width=True)
            if answer.get("sql"):
                st.code(answer["sql"], language="sql")
        except Exception as exc:
            st.error(str(exc))
    metrics_path = export_metrics_csv(state.run_id)
    st.download_button("⬇️ Download run metrics", Path(metrics_path).read_bytes(), file_name=Path(metrics_path).name, mime="text/csv")
    if st.button("Start another run"):
        st.session_state.state = None
        st.rerun()

elif state.status == "failed":
    st.error(f"Run failed in phase `{state.failed_phase}`: {state.error}")
    st.json(state.to_dict())
    if st.button("Start a new run"):
        st.session_state.state = None
        st.rerun()

st.divider()
render_admin_dashboard()
