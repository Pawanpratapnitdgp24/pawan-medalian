from __future__ import annotations

import shutil
from pathlib import Path
from tempfile import NamedTemporaryFile
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import FileResponse

from core.config import APP_NAME, LANDING_DIR, MAX_UPLOAD_MB
from core.run_store import load_state
from agents.orchestrator import new_run, run_until_bronze_sttm

app = FastAPI(title=APP_NAME, version="1.0.0")


@app.get("/health")
def health():
    return {"status": "ok", "service": APP_NAME}


@app.post("/runs")
async def create_run(business_intent: str = Form(...), files: list[UploadFile] = File(...)):
    if not files:
        raise HTTPException(400, "At least one CSV file is required.")
    saved = []
    for uploaded in files:
        if not uploaded.filename or not uploaded.filename.lower().endswith(".csv"):
            raise HTTPException(400, "Only CSV files are accepted.")
        data = await uploaded.read()
        if len(data) > MAX_UPLOAD_MB * 1024 * 1024:
            raise HTTPException(413, f"{uploaded.filename} exceeds the upload size limit.")
        target = LANDING_DIR / Path(uploaded.filename).name
        target.write_bytes(data)
        saved.append(str(target))
    state = new_run(business_intent, saved)
    run_until_bronze_sttm(state)
    return state.to_dict()


@app.get("/runs/{run_id}")
def get_run(run_id: str):
    state = load_state(run_id)
    if state is None:
        raise HTTPException(404, "Run not found.")
    return state.to_dict()


@app.get("/runs/{run_id}/report")
def download_report(run_id: str):
    state = load_state(run_id)
    if state is None or not state.report_path:
        raise HTTPException(404, "Report not available.")
    path = Path(state.report_path)
    if not path.exists():
        raise HTTPException(404, "Report file is missing.")
    return FileResponse(path, media_type="text/html", filename=path.name)
