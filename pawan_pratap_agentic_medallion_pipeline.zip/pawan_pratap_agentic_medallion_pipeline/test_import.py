"""Fast import/syntax sanity check for local development and CI."""

mods = [
    "core.config", "core.audit", "core.cache", "core.custom_transforms", "core.data_quality",
    "core.lineage", "core.memory", "core.metrics", "core.notifications", "core.observability",
    "core.retry", "core.run_store", "core.state", "core.sttm_versioning",
    "agents.llm_client", "agents.profiler", "agents.sttm_generator", "agents.bronze_agent",
    "agents.silver_agent", "agents.gold_agent", "agents.reporter", "agents.orchestrator",
]

for name in mods:
    __import__(name)

print("✅ SUCCESS! Core and agent imports worked.")
