from __future__ import annotations


def build_lineage_graph(state) -> dict:
    nodes = [
        {"id": "landing", "label": "Landing CSVs", "kind": "source"},
        {"id": "bronze", "label": "Bronze Parquet", "kind": "transform"},
        {"id": "silver", "label": "Silver Parquet", "kind": "transform"},
        {"id": "gold", "label": "Gold Parquet", "kind": "analytics"},
        {"id": "report", "label": "Executive Report", "kind": "output"},
    ]
    edges = [
        {"source": "landing", "target": "bronze"},
        {"source": "bronze", "target": "silver"},
        {"source": "silver", "target": "gold"},
        {"source": "gold", "target": "report"},
    ]
    return {"nodes": nodes, "edges": edges, "run_id": state.run_id}


def build_mermaid_diagram(state) -> str:
    return """graph LR\n  A[Landing CSVs] --> B[Bronze]\n  B --> C[Silver]\n  C --> D[Gold]\n  D --> E[Executive Report]\n"""
