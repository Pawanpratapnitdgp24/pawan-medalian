from __future__ import annotations

import json
from datetime import datetime, timezone
from core.config import TRACE_DIR


class AgentTrace:
    def __init__(self, agent: str, run_id: str):
        self.agent = agent
        self.run_id = run_id
        self.started_at = datetime.now(timezone.utc).isoformat()
        self.events: list[dict] = []
        self.input: dict = {}
        self.output: dict = {}
        self.error: str | None = None

    def set_input(self, **payload):
        self.input = payload
        return self

    def set_output(self, **payload):
        self.output = payload
        return self

    def event(self, name: str, **payload):
        self.events.append({"at": datetime.now(timezone.utc).isoformat(), "event": name, **payload})
        return self

    def fail(self, message: str):
        self.error = message
        self.write()
        return self

    def complete(self):
        self.write()
        return self

    def write(self):
        payload = {
            "agent": self.agent,
            "run_id": self.run_id,
            "started_at": self.started_at,
            "input": self.input,
            "output": self.output,
            "events": self.events,
            "error": self.error,
        }
        (TRACE_DIR / f"{self.agent}_{self.run_id[:8]}.json").write_text(
            json.dumps(payload, indent=2, default=str), encoding="utf-8"
        )
