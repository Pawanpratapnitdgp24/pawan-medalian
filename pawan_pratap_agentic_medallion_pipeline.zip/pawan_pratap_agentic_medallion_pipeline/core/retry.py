from __future__ import annotations

import time
from collections.abc import Callable


def with_retry(fn: Callable, attempts: int = 3, base_delay: float = 1.0):
    last = None
    for attempt in range(attempts):
        try:
            return fn()
        except Exception as exc:
            last = exc
            if attempt == attempts - 1:
                raise
            time.sleep(base_delay * (2 ** attempt))
    raise last
