from __future__ import annotations

import csv
import json
import time
from pathlib import Path
from core.config import METRICS_DIR


class MemoryTracker:
    def __init__(self, run_id: str, agent: str):
        self.run_id = run_id
        self.agent = agent
        self.started = None

    def __enter__(self):
        self.started = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc, tb):
        duration_ms = round((time.perf_counter() - self.started) * 1000, 2)
        record_metric(self.run_id, self.agent, duration_ms, bool(exc))


def record_metric(run_id: str, agent: str, duration_ms: float, failed: bool):
    path = METRICS_DIR / f"{run_id}.jsonl"
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"agent": agent, "duration_ms": duration_ms, "failed": failed}) + "\n")


def summarize_run(run_id: str) -> dict:
    path = METRICS_DIR / f"{run_id}.jsonl"
    if not path.exists():
        return {"run_id": run_id, "agents": 0, "duration_ms": 0, "failures": 0}
    records = [json.loads(x) for x in path.read_text().splitlines() if x.strip()]
    return {
        "run_id": run_id,
        "agents": len(records),
        "duration_ms": round(sum(r["duration_ms"] for r in records), 2),
        "failures": sum(1 for r in records if r["failed"]),
    }


def export_metrics_csv(run_id: str) -> str:
    source = METRICS_DIR / f"{run_id}.jsonl"
    target = METRICS_DIR / f"{run_id}.csv"
    records = [json.loads(x) for x in source.read_text().splitlines() if x.strip()] if source.exists() else []
    with target.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=["agent", "duration_ms", "failed"])
        writer.writeheader()
        writer.writerows(records)
    return str(target)
