from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any


@dataclass
class PipelineState:
    run_id: str
    status: str = "created"
    phase: str = "upload"
    uploaded_files: list[str] = field(default_factory=list)
    business_intent: str = ""
    profile_path: str = ""
    sttm_bronze_path: str = ""
    sttm_silver_path: str = ""
    sttm_gold_path: str = ""
    bronze_sttm_approved: bool = False
    silver_sttm_approved: bool = False
    gold_sttm_approved: bool = False
    bronze_output_paths: list[str] = field(default_factory=list)
    silver_output_paths: list[str] = field(default_factory=list)
    gold_output_paths: list[str] = field(default_factory=list)
    report_path: str = ""
    error: str = ""
    failed_phase: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict):
        return cls(**data)
