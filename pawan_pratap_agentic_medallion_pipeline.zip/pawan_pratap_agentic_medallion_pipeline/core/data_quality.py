from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from core.config import QUALITY_MAX_NULL_PCT, QUALITY_MIN_SCORE_TO_PASS, QUALITY_DIR, QUALITY_FAIL_ON_LOW_SCORE
from core.exceptions import DataQualityError


def run_quality_checks(df: pd.DataFrame, table_name: str, layer: str) -> dict:
    rows = len(df)
    cols = len(df.columns)
    null_pct = float(df.isna().mean().mean() * 100) if rows and cols else 100.0
    duplicate_pct = float(df.duplicated().mean() * 100) if rows else 100.0
    schema_health = 100.0 if cols else 0.0
    completeness = max(0.0, 100.0 - null_pct)
    uniqueness = max(0.0, 100.0 - duplicate_pct)
    score = round(0.5 * completeness + 0.3 * uniqueness + 0.2 * schema_health, 2)
    passed = score >= QUALITY_MIN_SCORE_TO_PASS and null_pct <= QUALITY_MAX_NULL_PCT and cols > 0
    return {
        "table": table_name,
        "layer": layer,
        "rows": rows,
        "columns": cols,
        "null_pct": round(null_pct, 2),
        "duplicate_pct": round(duplicate_pct, 2),
        "score": score,
        "passed": passed,
        "threshold": QUALITY_MIN_SCORE_TO_PASS,
    }


def save_quality_report(report: dict, run_id: str):
    folder = QUALITY_DIR / run_id[:8]
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{report['layer']}_{report['table']}.json"
    path.write_text(json.dumps(report, indent=2, default=str), encoding="utf-8")
    return str(path)


def enforce_quality_gate(report: dict, run_id: str):
    if QUALITY_FAIL_ON_LOW_SCORE and not report["passed"]:
        raise DataQualityError(
            f"Quality gate failed for {report['layer']}/{report['table']} (score {report['score']}).",
            score=report["score"],
            run_id=run_id,
        )
