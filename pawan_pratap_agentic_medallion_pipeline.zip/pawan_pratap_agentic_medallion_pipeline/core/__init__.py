"""Core services for configuration, state, audit, quality, and persistence."""
