from __future__ import annotations

import json
from core.config import RUNS_DIR
from core.state import PipelineState


def save_state(state: PipelineState):
    path = RUNS_DIR / f"{state.run_id}.json"
    path.write_text(json.dumps(state.to_dict(), indent=2, default=str), encoding="utf-8")
    return str(path)


def load_state(run_id: str):
    path = RUNS_DIR / f"{run_id}.json"
    if not path.exists():
        return None
    return PipelineState.from_dict(json.loads(path.read_text(encoding="utf-8")))
