from __future__ import annotations

import json
import re
from core.config import ROOT

MEMORY_PATH = ROOT / ".memory" / "memory.json"
MEMORY_PATH.parent.mkdir(exist_ok=True)


def _tokens(text: str) -> set[str]:
    return {x.lower() for x in re.findall(r"[A-Za-z0-9_]+", text) if len(x) > 2}


def remember(run_id: str, text: str, metadata: dict | None = None):
    records = []
    if MEMORY_PATH.exists():
        records = json.loads(MEMORY_PATH.read_text(encoding="utf-8"))
    records.append({"run_id": run_id, "text": text, "metadata": metadata or {}})
    MEMORY_PATH.write_text(json.dumps(records[-100:], indent=2), encoding="utf-8")


def search(query: str, top_k: int = 5) -> list[dict]:
    if not MEMORY_PATH.exists():
        return []
    q = _tokens(query)
    rows = json.loads(MEMORY_PATH.read_text(encoding="utf-8"))
    scored = []
    for row in rows:
        score = len(q & _tokens(row.get("text", "")))
        if score:
            scored.append((score, row))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [r for _, r in scored[:top_k]]
