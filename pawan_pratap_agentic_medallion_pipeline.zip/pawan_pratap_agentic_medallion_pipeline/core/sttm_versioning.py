from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
import pandas as pd
from core.config import STTM_VERSIONS_DIR


def save_sttm_version(sttm_path: str, run_id: str, layer: str) -> str:
    src = Path(sttm_path)
    folder = STTM_VERSIONS_DIR / run_id[:8] / layer
    folder.mkdir(parents=True, exist_ok=True)
    version = len(list(folder.glob("v*.csv"))) + 1
    target = folder / f"v{version}.csv"
    target.write_bytes(src.read_bytes())
    return str(target)


def get_version_history(run_id: str, layer: str) -> list[str]:
    folder = STTM_VERSIONS_DIR / run_id[:8] / layer
    return [str(x) for x in sorted(folder.glob("v*.csv"))] if folder.exists() else []


def diff_versions(left: str, right: str) -> dict:
    a = pd.read_csv(left).fillna("")
    b = pd.read_csv(right).fillna("")
    return {"left_rows": len(a), "right_rows": len(b), "left_columns": list(a.columns), "right_columns": list(b.columns)}


def restore_version(version_path: str, target_path: str) -> str:
    Path(target_path).write_bytes(Path(version_path).read_bytes())
    return target_path
