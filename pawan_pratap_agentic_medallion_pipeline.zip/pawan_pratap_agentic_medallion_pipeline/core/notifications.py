from __future__ import annotations

from email.message import EmailMessage
import smtplib
from core.config import EMAIL_NOTIFICATIONS_ENABLED, SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD, EMAIL_FROM, EMAIL_TO


def send_report_email(subject: str, html_body: str) -> bool:
    if not EMAIL_NOTIFICATIONS_ENABLED or not EMAIL_TO or not SMTP_HOST:
        return False
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = EMAIL_FROM or SMTP_USERNAME
    msg["To"] = EMAIL_TO
    msg.set_content("Your Pawan Pratap analytics report is ready.")
    msg.add_alternative(html_body, subtype="html")
    with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=20) as smtp:
        smtp.starttls()
        if SMTP_USERNAME:
            smtp.login(SMTP_USERNAME, SMTP_PASSWORD)
        smtp.send_message(msg)
    return True
