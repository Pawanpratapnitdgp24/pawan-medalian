from __future__ import annotations

import ast
import re
import pandas as pd

ALLOWED = {
    "abs": abs, "round": round, "min": min, "max": max,
    "len": len, "str": str, "int": int, "float": float,
}
ALLOWED_NODES = (
    ast.Expression, ast.BinOp, ast.UnaryOp, ast.BoolOp, ast.Compare, ast.Constant,
    ast.Name, ast.Load, ast.Call, ast.IfExp, ast.List, ast.Tuple,
    ast.Add, ast.Sub, ast.Mult, ast.Div, ast.FloorDiv, ast.Mod, ast.Pow,
    ast.USub, ast.UAdd, ast.Not, ast.And, ast.Or, ast.Eq, ast.NotEq,
    ast.Lt, ast.LtE, ast.Gt, ast.GtE, ast.In, ast.NotIn,
)


def validate_expression(expression: str, allowed_names: set[str]):
    if not expression or len(expression) > 300:
        raise ValueError("Expression is empty or exceeds 300 characters.")
    tree = ast.parse(expression, mode="eval")
    for node in ast.walk(tree):
        if not isinstance(node, ALLOWED_NODES):
            raise ValueError(f"Disallowed expression element: {type(node).__name__}")
        if isinstance(node, ast.Name) and node.id not in allowed_names and node.id not in ALLOWED:
            raise ValueError(f"Unknown identifier: {node.id}")
        if isinstance(node, ast.Call) and (not isinstance(node.func, ast.Name) or node.func.id not in ALLOWED):
            raise ValueError("Only whitelisted functions may be called.")
    return tree


def apply_custom_expression(df: pd.DataFrame, expression: str) -> pd.Series:
    tree = validate_expression(expression, set(df.columns))
    code = compile(tree, "<custom>", "eval")
    return df.apply(lambda row: eval(code, {"__builtins__": {}}, {**ALLOWED, **row.to_dict()}), axis=1)


def apply_regex_replace(series: pd.Series, pattern: str, replacement: str) -> pd.Series:
    if not pattern or len(pattern) > 200:
        raise ValueError("Regex pattern is empty or too long.")
    re.compile(pattern)
    return series.astype("string").str.replace(pattern, replacement, regex=True)


def apply_lookup(series: pd.Series, mapping: dict, default=None) -> pd.Series:
    return series.map(mapping).fillna(default)
