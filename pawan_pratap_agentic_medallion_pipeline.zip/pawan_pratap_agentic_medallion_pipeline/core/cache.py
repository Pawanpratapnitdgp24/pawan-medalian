from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from core.config import CACHE_DIR


def _fingerprint(value) -> str:
    if isinstance(value, (list, tuple)):
        return json.dumps([_fingerprint(x) for x in value], sort_keys=True)
    if isinstance(value, str) and Path(value).is_file():
        h = hashlib.sha256()
        with open(value, "rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    return str(value)


def compute_cache_key(*parts) -> str:
    blob = "|".join(_fingerprint(part) for part in parts).encode()
    return hashlib.sha256(blob).hexdigest()[:20]


def get_cached_result(key: str, namespace: str):
    path = CACHE_DIR / namespace / f"{key}.json"
    if not path.exists():
        return None
    return json.loads(path.read_text(encoding="utf-8"))


def set_cached_result(key: str, namespace: str, result, metadata=None):
    folder = CACHE_DIR / namespace
    folder.mkdir(parents=True, exist_ok=True)
    payload = {
        "cache_key": key,
        "namespace": namespace,
        "cached_at": datetime.now(timezone.utc).isoformat(),
        "result": result,
        "metadata": metadata or {},
    }
    (folder / f"{key}.json").write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")


def invalidate_cache(namespace: str | None = None) -> int:
    root = CACHE_DIR / namespace if namespace else CACHE_DIR
    removed = 0
    if root.exists():
        for path in root.rglob("*.json"):
            path.unlink()
            removed += 1
    return removed


def list_cache_entries():
    return [
        json.loads(path.read_text(encoding="utf-8"))
        for path in CACHE_DIR.rglob("*.json")
    ] if CACHE_DIR.exists() else []
