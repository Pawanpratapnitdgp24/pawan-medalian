class PipelineError(RuntimeError):
    pass


class AgentExecutionError(PipelineError):
    def __init__(self, message: str, *, phase: str = "", agent: str = "", run_id: str = ""):
        super().__init__(message)
        self.phase = phase
        self.agent = agent
        self.run_id = run_id


class DataQualityError(PipelineError):
    def __init__(self, message: str, *, score: float = 0.0, run_id: str = ""):
        super().__init__(message)
        self.score = score
        self.run_id = run_id
