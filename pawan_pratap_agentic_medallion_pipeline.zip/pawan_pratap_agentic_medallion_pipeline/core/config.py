from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

APP_NAME = os.getenv("APP_NAME", "Pawan Pratap — Agentic Medallion Pipeline")
AUTHOR_NAME = os.getenv("AUTHOR_NAME", "Pawan Pratap")

DATA_DIR = ROOT / "data"
LANDING_DIR = DATA_DIR / "landing"
PROFILES_DIR = DATA_DIR / "profiles"
STTM_DIR = DATA_DIR / "sttm"
BRONZE_DIR = DATA_DIR / "bronze_layer"
SILVER_DIR = DATA_DIR / "silver_layer"
GOLD_DIR = DATA_DIR / "gold_layer"
TRACE_DIR = DATA_DIR / "traces"
QUALITY_DIR = DATA_DIR / "quality"
RUNS_DIR = DATA_DIR / "runs"
CACHE_DIR = DATA_DIR / "cache"
USER_RUNS_DIR = DATA_DIR / "user_runs"
METRICS_DIR = DATA_DIR / "metrics"
STTM_VERSIONS_DIR = DATA_DIR / "sttm_versions"
REPORTS_DIR = ROOT / "reports"
AUDIT_DIR = ROOT / "audit_logs"

LLM_PROVIDER = os.getenv("LLM_PROVIDER", "").strip().lower()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")
GROQ_BASE_URL = os.getenv("GROQ_BASE_URL", "https://api.groq.com/openai/v1")
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_MODEL = os.getenv("GITHUB_MODEL", "openai/gpt-4.1-mini")
GITHUB_BASE_URL = os.getenv("GITHUB_BASE_URL", "https://models.inference.ai.azure.com")
ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-haiku-4-5")
ANTHROPIC_BASE_URL = os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.5-flash")

LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "8192"))
LLM_TIMEOUT_SECONDS = int(os.getenv("LLM_TIMEOUT_SECONDS", "60"))
QUALITY_MAX_NULL_PCT = float(os.getenv("QUALITY_MAX_NULL_PCT", "50"))
QUALITY_MIN_SCORE_TO_PASS = float(os.getenv("QUALITY_MIN_SCORE_TO_PASS", "70"))
QUALITY_FAIL_ON_LOW_SCORE = os.getenv("QUALITY_FAIL_ON_LOW_SCORE", "true").lower() == "true"
MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "50"))

EMAIL_NOTIFICATIONS_ENABLED = os.getenv("EMAIL_NOTIFICATIONS_ENABLED", "false").lower() == "true"
SMTP_HOST = os.getenv("SMTP_HOST", "")
SMTP_PORT = int(os.getenv("SMTP_PORT", "587"))
SMTP_USERNAME = os.getenv("SMTP_USERNAME", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
EMAIL_FROM = os.getenv("EMAIL_FROM", SMTP_USERNAME)
EMAIL_TO = os.getenv("EMAIL_TO", "")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")

for _path in [
    DATA_DIR, LANDING_DIR, PROFILES_DIR, STTM_DIR, BRONZE_DIR, SILVER_DIR, GOLD_DIR,
    TRACE_DIR, QUALITY_DIR, RUNS_DIR, CACHE_DIR, USER_RUNS_DIR, METRICS_DIR,
    STTM_VERSIONS_DIR, REPORTS_DIR, AUDIT_DIR
]:
    _path.mkdir(parents=True, exist_ok=True)


def detect_provider() -> str:
    if LLM_PROVIDER:
        return LLM_PROVIDER
    for name, key in [
        ("openai", OPENAI_API_KEY),
        ("groq", GROQ_API_KEY),
        ("github", GITHUB_TOKEN),
        ("anthropic", ANTHROPIC_API_KEY),
        ("gemini", GOOGLE_API_KEY),
    ]:
        if key:
            return name
    return ""


def has_llm() -> bool:
    return bool(detect_provider())
