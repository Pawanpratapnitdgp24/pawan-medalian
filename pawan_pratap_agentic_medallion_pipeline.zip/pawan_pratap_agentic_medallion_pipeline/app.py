"""Convenience launcher for platforms that expect a root Streamlit file."""
exec(compile(open("app/streamlit_app.py", "r", encoding="utf-8").read(), "app/streamlit_app.py", "exec"))
