from __future__ import annotations
import streamlit as st
from admin_stats import collect_system_stats, recent_runs
from core.config import ADMIN_PASSWORD


def render_admin_dashboard():
    st.subheader("Admin / Operations")
    if not ADMIN_PASSWORD:
        st.info("Admin dashboard is disabled until ADMIN_PASSWORD is set in environment/secrets.")
        return
    password = st.text_input("Admin password", type="password")
    if password != ADMIN_PASSWORD:
        return
    stats = collect_system_stats()
    cols = st.columns(5)
    for col, (key, value) in zip(cols, stats.items()):
        col.metric(key.replace("_", " ").title(), value)
    st.dataframe(recent_runs(), use_container_width=True)
