# Security

Do not commit `.env`, provider API keys, SMTP passwords, database passwords, or other secrets.

For a deployed public Streamlit app, treat uploaded CSV files and generated reports as potentially sensitive business data. Use a private repository / controlled hosting when appropriate.

Report security issues privately to the repository owner rather than opening a public issue with exploit details.
