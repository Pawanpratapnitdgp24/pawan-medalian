from __future__ import annotations

import json
import platform
from pathlib import Path
import psutil
from core.config import AUDIT_DIR, RUNS_DIR


def collect_system_stats() -> dict:
    return {
        "platform": platform.platform(),
        "python": platform.python_version(),
        "cpu_percent": psutil.cpu_percent(interval=0.1),
        "memory_percent": psutil.virtual_memory().percent,
        "disk_percent": psutil.disk_usage(Path.cwd()).percent,
        "run_files": len(list(RUNS_DIR.glob("*.json"))),
        "audit_files": len(list(AUDIT_DIR.glob("*.jsonl"))),
    }


def recent_runs(limit: int = 10) -> list[dict]:
    items = []
    for path in sorted(RUNS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:limit]:
        try:
            items.append(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            pass
    return items
