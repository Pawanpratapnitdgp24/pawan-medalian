from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import plotly.express as px

from agents.llm_client import LLMClient
from core.audit import AuditLogger
from core.config import REPORTS_DIR
from core.observability import AgentTrace


READ_ONLY = re.compile(r"^\s*(select|with)\b", flags=re.I)


def _table_name(path: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", Path(path).stem)


def _safe_sql(sql: str) -> str:
    sql = sql.strip().rstrip(";").strip()
    if not READ_ONLY.match(sql):
        raise ValueError("Only read-only SELECT/WITH SQL is permitted.")
    forbidden = [" insert ", " update ", " delete ", " drop ", " alter ", " create ", " copy ", " attach ", " install ", " load "]
    padded = f" {sql.lower()} "
    if any(word in padded for word in forbidden):
        raise ValueError("Unsafe SQL detected.")
    return sql


def _load(con, files: list[str]):
    tables = {}
    for file in files:
        name = _table_name(file)
        con.execute(f"CREATE OR REPLACE TABLE {name} AS SELECT * FROM read_parquet(?)", [file])
        tables[name] = con.execute(f"DESCRIBE {name}").fetchdf().to_dict("records")
    return tables


def _fallback_analysis(files: list[str], business_intent: str):
    summary = next((f for f in files if "summary" in Path(f).name), files[0])
    df = pd.read_parquet(summary)
    nums = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    dims = [c for c in df.columns if not pd.api.types.is_numeric_dtype(df[c])]
    if dims and nums:
        measure = next((c for c in nums if "sum" in c.lower()), nums[0])
        top = df.sort_values(measure, ascending=False).head(5)
        direct = f"Based on the generated Gold summary, {top.iloc[0][dims[0]]!s} is the leading segment by {measure} ({top.iloc[0][measure]:,.2f})."
        chart = {"type": "bar", "title": f"{measure} by {dims[0]}", "x_column": dims[0], "y_column": measure}
    else:
        measure = nums[0] if nums else df.columns[-1]
        direct = f"The analytics output contains {len(df):,} records. The leading available numeric measure is {measure}."
        chart = None
    return {"direct_answer": direct, "charts": [chart] if chart else [], "detailed_analysis": f"Business question: {business_intent}\n\nThe report was produced from the Gold layer using read-only DuckDB queries."}


def build_chart(df: pd.DataFrame, spec: dict):
    chart_type = str(spec.get("type", "bar")).lower()
    x = spec.get("x_column")
    y = spec.get("y_column")
    if x not in df.columns or y not in df.columns:
        return None
    if chart_type == "line": return px.line(df, x=x, y=y, title=spec.get("title", "Chart"))
    if chart_type == "pie": return px.pie(df, names=x, values=y, title=spec.get("title", "Chart"))
    if chart_type == "scatter": return px.scatter(df, x=x, y=y, title=spec.get("title", "Chart"))
    return px.bar(df, x=x, y=y, title=spec.get("title", "Chart"))


def generate_report(gold_files: list[str], business_intent: str, run_id: str) -> str:
    trace = AgentTrace("reporter", run_id).set_input(gold_files=gold_files, business_intent=business_intent)
    audit = AuditLogger(run_id)
    import duckdb
    con = duckdb.connect(database=":memory:")
    try:
        catalog = _load(con, gold_files)
        sample = {}
        for name in catalog:
            sample[name] = con.execute(f"SELECT * FROM {name} LIMIT 8").fetchdf().to_dict("records")
        fallback = _fallback_analysis(gold_files, business_intent)
        analysis = LLMClient().json(
            "You are an executive analytics reporter. Return JSON with direct_answer, charts, detailed_analysis. charts must reference real columns.",
            json.dumps({"intent": business_intent, "catalog": catalog, "sample": sample}, default=str),
            fallback,
        )
        chart_html = []
        for idx, spec in enumerate(analysis.get("charts", [])):
            if not spec: continue
            candidates = [con.execute(f"SELECT * FROM {name}").fetchdf() for name in catalog]
            for df in candidates:
                fig = build_chart(df, spec)
                if fig is not None:
                    chart_html.append(fig.to_html(full_html=False, include_plotlyjs=(idx == 0)))
                    break
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        report_path = REPORTS_DIR / f"report_{run_id[:8]}_{timestamp}.html"
        html = f"""<!doctype html><html><head><meta charset='utf-8'><title>Pawan Pratap — Executive Report</title>
        <style>body{{font-family:Inter,Arial,sans-serif;max-width:1100px;margin:40px auto;padding:0 24px;color:#152033}}.hero{{padding:24px;border-radius:18px;background:linear-gradient(135deg,#111827,#334155);color:#fff}}.card{{padding:20px;margin:18px 0;border:1px solid #e5e7eb;border-radius:14px}}pre{{white-space:pre-wrap}}</style></head><body>
        <div class='hero'><h1>Pawan Pratap — Executive Analytics Report</h1><p>{business_intent}</p><p>Run: {run_id}</p></div>
        <div class='card'><h2>Direct answer</h2><p>{analysis.get('direct_answer','')}</p></div>
        <div class='card'><h2>Detailed analysis</h2><pre>{analysis.get('detailed_analysis','')}</pre></div>
        {''.join(f"<div class='card'><h2>Chart {i+1}</h2>{chart}</div>" for i, chart in enumerate(chart_html))}
        <div class='card'><h2>Gold catalog</h2><pre>{json.dumps(catalog, indent=2, default=str)}</pre></div>
        </body></html>"""
        report_path.write_text(html, encoding="utf-8")
        trace.set_output(report_path=str(report_path), catalog=list(catalog)).complete()
        audit.log("reporter", "complete", report_path=str(report_path))
        return str(report_path)
    except Exception as exc:
        trace.fail(str(exc)); audit.log("reporter", "failed", error=str(exc)); raise


def answer_followup_question(gold_files: list[str], question: str, run_id: str, prior_context: str = "") -> dict:
    import duckdb
    con = duckdb.connect(database=":memory:")
    catalog = _load(con, gold_files)
    prompt = {"question": question, "prior_context": prior_context, "tables": catalog}
    heuristic = {"direct_answer": "Use the Gold tables to answer the question.", "sql": "", "chart": None}
    proposal = LLMClient().json(
        "Return JSON with direct_answer, sql, chart. SQL must be read-only SELECT/WITH and use only catalog tables.",
        json.dumps(prompt, default=str), heuristic,
    )
    sql = proposal.get("sql", "")
    if sql:
        sql = _safe_sql(sql)
        result = con.execute(sql).fetchdf()
        answer = proposal.get("direct_answer", "Query completed.")
        return {**proposal, "direct_answer": answer, "rows": result.to_dict("records")}
    return proposal
