from __future__ import annotations

import json
import re
from pathlib import Path
import pandas as pd

from agents.llm_client import LLMClient
from core.audit import AuditLogger
from core.cache import compute_cache_key, get_cached_result, set_cached_result
from core.config import STTM_DIR
from core.observability import AgentTrace
from core.sttm_versioning import save_sttm_version

STTM_COLUMNS = [
    "source_table", "source_column", "target_table", "target_column",
    "data_type", "transformation_type", "transformation_logic", "business_rule",
]


def _clean_name(value: str) -> str:
    value = re.sub(r"[^0-9A-Za-z]+", "_", value.strip()).strip("_").lower()
    return value or "unnamed"


def _dtype(series: pd.Series) -> str:
    if pd.api.types.is_bool_dtype(series): return "BOOLEAN"
    if pd.api.types.is_integer_dtype(series): return "INTEGER"
    if pd.api.types.is_float_dtype(series): return "DOUBLE"
    if pd.api.types.is_string_dtype(series):
        parsed = pd.to_datetime(series, errors="coerce", format="mixed")
        if len(series) and parsed.notna().mean() > 0.85: return "TIMESTAMP"
    return "STRING"


def _bronze_rules(files: list[str]) -> list[dict]:
    rows = []
    for path in files:
        table = Path(path).stem
        df = pd.read_csv(path)
        for col in df.columns:
            rows.append({
                "source_table": table,
                "source_column": col,
                "target_table": f"{_clean_name(table)}_bronze",
                "target_column": _clean_name(col),
                "data_type": _dtype(df[col]),
                "transformation_type": "rename_and_cast",
                "transformation_logic": f"rename '{col}' to '{_clean_name(col)}'; cast as {_dtype(df[col])}",
                "business_rule": "Preserve source semantics; add ingestion metadata.",
            })
    return rows


def _silver_rules(bronze_files: list[str]) -> list[dict]:
    rows = []
    for path in bronze_files:
        table = Path(path).stem.replace("_bronze", "") + "_silver"
        df = pd.read_parquet(path)
        for col in df.columns:
            if col.startswith("_"):
                continue
            dtype = _dtype(df[col])
            if dtype in {"INTEGER", "DOUBLE"}:
                logic = "coerce numeric; fill nulls with column median"
                kind = "numeric_clean"
            elif dtype == "TIMESTAMP":
                logic = "parse timestamp; invalid values become null"
                kind = "date_standardize"
            else:
                logic = "trim whitespace; normalize repeated spaces"
                kind = "text_normalize"
            rows.append({
                "source_table": Path(path).stem,
                "source_column": col,
                "target_table": table,
                "target_column": col,
                "data_type": dtype,
                "transformation_type": kind,
                "transformation_logic": logic,
                "business_rule": "Deduplicate at table level and standardize values.",
            })
    return rows


def _gold_rules(silver_files: list[str], business_intent: str) -> list[dict]:
    rows = []
    for path in silver_files:
        df = pd.read_parquet(path)
        table = Path(path).stem
        for col in df.columns:
            if col.startswith("_"):
                continue
            rows.append({
                "source_table": table,
                "source_column": col,
                "target_table": "gold_analytics",
                "target_column": col,
                "data_type": _dtype(df[col]),
                "transformation_type": "join_or_aggregate",
                "transformation_logic": "Use shared keys for joins; aggregate numeric measures for analytics.",
                "business_rule": business_intent[:300],
            })
    return rows


def _write(rows: list[dict], layer: str, run_id: str, metadata: str):
    if not rows:
        raise ValueError(f"No {layer} STTM rows generated.")
    key = compute_cache_key(layer, metadata, rows)
    # Cache is only advisory; write a fresh version for the current run.
    frame = pd.DataFrame(rows, columns=STTM_COLUMNS)
    path = STTM_DIR / f"{layer}_sttm_{run_id[:8]}.csv"
    frame.to_csv(path, index=False)
    save_sttm_version(str(path), run_id, layer)
    return str(path)


def generate_bronze_sttm(profile_path: str, run_id: str, task_description: str) -> str:
    trace = AgentTrace("sttm_bronze", run_id).set_input(profile_path=profile_path)
    payload = json.loads(Path(profile_path).read_text(encoding="utf-8"))
    files = list(payload.get("files", {}).keys())
    rows = _bronze_rules(files)
    llm = LLMClient().json(
        "Return a JSON array of Bronze STTM objects. Preserve every source column.",
        json.dumps({"rules": rows, "task": task_description}), rows,
    )
    path = _write(llm if isinstance(llm, list) and llm else rows, "bronze", run_id, task_description)
    trace.set_output(path=path).complete(); AuditLogger(run_id).log("sttm_generator", "bronze_generated", path=path)
    return path


def generate_silver_sttm(bronze_files: list[str], bronze_sttm_path: str, run_id: str, task_description: str) -> str:
    trace = AgentTrace("sttm_silver", run_id).set_input(bronze_files=bronze_files)
    rows = _silver_rules(bronze_files)
    llm = LLMClient().json(
        "Return a JSON array of Silver STTM rules for cleansing and standardization.",
        json.dumps({"rules": rows, "task": task_description}), rows,
    )
    path = _write(llm if isinstance(llm, list) and llm else rows, "silver", run_id, task_description)
    trace.set_output(path=path).complete(); AuditLogger(run_id).log("sttm_generator", "silver_generated", path=path)
    return path


def generate_gold_sttm(silver_files: list[str], silver_sttm_path: str, business_intent: str, run_id: str, task_description: str) -> str:
    trace = AgentTrace("sttm_gold", run_id).set_input(silver_files=silver_files, business_intent=business_intent)
    rows = _gold_rules(silver_files, business_intent)
    llm = LLMClient().json(
        "Return a JSON array of Gold STTM rules covering joins, dimensions and measures.",
        json.dumps({"rules": rows, "task": task_description, "intent": business_intent}), rows,
    )
    path = _write(llm if isinstance(llm, list) and llm else rows, "gold", run_id, task_description)
    trace.set_output(path=path).complete(); AuditLogger(run_id).log("sttm_generator", "gold_generated", path=path)
    return path
