from __future__ import annotations

from pathlib import Path
import pandas as pd
from agents.llm_client import LLMClient
from core.audit import AuditLogger
from core.config import SILVER_DIR
from core.observability import AgentTrace


def execute_silver(bronze_files: list[str], sttm_path: str, run_id: str, task_description: str) -> list[str]:
    trace = AgentTrace("silver", run_id).set_input(bronze_files=bronze_files, sttm_path=sttm_path)
    audit = AuditLogger(run_id)
    rules = pd.read_csv(sttm_path)
    out_dir = SILVER_DIR / run_id[:8]
    out_dir.mkdir(parents=True, exist_ok=True)
    outputs = []
    try:
        for file in bronze_files:
            df = pd.read_parquet(file)
            subset = rules[rules["source_table"].astype(str) == Path(file).stem]
            for _, rule in subset.iterrows():
                col = rule["target_column"]
                if col not in df.columns:
                    continue
                kind = str(rule["transformation_type"])
                if kind == "numeric_clean":
                    df[col] = pd.to_numeric(df[col], errors="coerce")
                    if df[col].notna().any():
                        df[col] = df[col].fillna(df[col].median())
                elif kind == "date_standardize":
                    df[col] = pd.to_datetime(df[col], errors="coerce", utc=True)
                else:
                    df[col] = df[col].astype("string").str.strip().str.replace(r"\s+", " ", regex=True)
            before = len(df)
            df = df.drop_duplicates().reset_index(drop=True)
            df["_silver_record_id"] = [f"{run_id[:8]}-{i:08d}" for i in range(len(df))]
            path = out_dir / f"{Path(file).stem.replace('_bronze','')}_silver.parquet"
            df.to_parquet(path, index=False)
            outputs.append(str(path))
            audit.log("silver_agent", "deduplicated", table=Path(file).stem, before=before, after=len(df))
        trace.set_output(outputs=outputs).complete()
        audit.log("silver_agent", "complete", outputs=outputs)
        return outputs
    except Exception as exc:
        trace.fail(str(exc)); audit.log("silver_agent", "failed", error=str(exc)); raise
