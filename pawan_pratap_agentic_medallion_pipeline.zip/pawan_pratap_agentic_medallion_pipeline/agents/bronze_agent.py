from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
import pandas as pd

from core.audit import AuditLogger
from core.config import BRONZE_DIR
from core.observability import AgentTrace


def _coerce(series: pd.Series, data_type: str) -> pd.Series:
    dtype = str(data_type).upper()
    if dtype in {"INTEGER", "DOUBLE", "DECIMAL"}:
        return pd.to_numeric(series, errors="coerce")
    if dtype == "TIMESTAMP":
        return pd.to_datetime(series, errors="coerce")
    return series


def execute_bronze(input_files: list[str], sttm_path: str, run_id: str, task_description: str) -> list[str]:
    trace = AgentTrace("bronze", run_id).set_input(input_files=input_files, sttm_path=sttm_path)
    audit = AuditLogger(run_id)
    rules = pd.read_csv(sttm_path)
    out_dir = BRONZE_DIR / run_id[:8]
    out_dir.mkdir(parents=True, exist_ok=True)
    outputs = []
    try:
        for file in input_files:
            df = pd.read_csv(file)
            table = Path(file).stem
            subset = rules[rules["source_table"].astype(str) == table]
            rename = dict(zip(subset["source_column"], subset["target_column"]))
            df = df.rename(columns=rename)
            for _, rule in subset.iterrows():
                col = rule["target_column"]
                if col in df.columns:
                    df[col] = _coerce(df[col], rule["data_type"])
            df["_load_timestamp"] = datetime.now(timezone.utc).isoformat()
            df["_source_file"] = str(file)
            path = out_dir / f"{table}_bronze.parquet"
            df.to_parquet(path, index=False)
            outputs.append(str(path))
        trace.set_output(outputs=outputs).complete()
        audit.log("bronze_agent", "complete", outputs=outputs)
        return outputs
    except Exception as exc:
        trace.fail(str(exc)); audit.log("bronze_agent", "failed", error=str(exc)); raise
