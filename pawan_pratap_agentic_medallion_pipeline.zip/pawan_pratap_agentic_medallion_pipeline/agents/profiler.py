from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd

from agents.llm_client import LLMClient
from core.audit import AuditLogger
from core.cache import compute_cache_key, get_cached_result, set_cached_result
from core.config import PROFILES_DIR
from core.observability import AgentTrace


def _safe(value: Any):
    if pd.isna(value):
        return None
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def inspect_files(file_paths: list[str]) -> dict:
    result = {}
    for path in file_paths:
        df = pd.read_csv(path)
        result[path] = {
            "rows": len(df),
            "columns": list(df.columns),
            "dtypes": {col: str(dtype) for col, dtype in df.dtypes.items()},
            "samples": {col: [_safe(x) for x in df[col].dropna().head(3).tolist()] for col in df.columns},
        }
    return result


def compute_profile(file_paths: list[str]) -> dict:
    details = {}
    all_columns = {}
    for path in file_paths:
        df = pd.read_csv(path)
        column_stats = {}
        for col in df.columns:
            s = df[col]
            stat = {
                "dtype": str(s.dtype),
                "null_count": int(s.isna().sum()),
                "null_pct": round(float(s.isna().mean() * 100), 2),
                "unique_count": int(s.nunique(dropna=True)),
                "duplicate_count": int(s.duplicated().sum()),
                "samples": [_safe(x) for x in s.dropna().head(5).tolist()],
            }
            if pd.api.types.is_numeric_dtype(s):
                n = pd.to_numeric(s, errors="coerce").dropna()
                stat.update({
                    "min": _safe(n.min()) if len(n) else None,
                    "max": _safe(n.max()) if len(n) else None,
                    "mean": round(float(n.mean()), 4) if len(n) else None,
                })
            column_stats[col] = stat
            all_columns.setdefault(col, []).append(path)
        details[path] = {"rows": len(df), "columns": column_stats}
    join_candidates = [name for name, paths in all_columns.items() if len(paths) > 1]
    return {"files": details, "join_candidates": join_candidates}


def _semantic_fallback(profile: dict) -> dict:
    meanings = {}
    quality = []
    join_keys = profile.get("join_candidates", [])
    for path, file_info in profile["files"].items():
        for col, stat in file_info["columns"].items():
            low = col.lower()
            if low.endswith("_id") or low in {"id", "sku", "product_id", "store_id", "customer_id"}:
                meaning = "Identifier / business key"
            elif "date" in low or "time" in low:
                meaning = "Date or timestamp"
            elif any(token in low for token in ["amount", "revenue", "sales", "price", "cost", "qty", "quantity"]):
                meaning = "Numeric business measure"
            elif any(token in low for token in ["region", "category", "type", "name", "city", "state"]):
                meaning = "Descriptive dimension"
            else:
                meaning = "Source attribute"
            meanings[f"{Path(path).stem}.{col}"] = meaning
            if stat["null_pct"] > 30:
                quality.append(f"{Path(path).name}.{col} has {stat['null_pct']}% null values.")
            if stat["unique_count"] <= 1:
                quality.append(f"{Path(path).name}.{col} has a single observed value.")
    return {"semantic_meanings": meanings, "join_keys": join_keys, "quality_notes": quality}


def profile_multiple_datasets(file_paths: list[str], run_id: str, task_description: str) -> str:
    trace = AgentTrace("profiler", run_id).set_input(file_paths=file_paths, task_description=task_description)
    audit = AuditLogger(run_id)
    key = compute_cache_key(file_paths, task_description)
    cached = get_cached_result(key, "profiles")
    try:
        profile = cached["result"] if cached else compute_profile(file_paths)
        enrichment = _semantic_fallback(profile)
        llm_payload = {"profile": profile, "task": task_description, "fallback": enrichment}
        llm_result = LLMClient().json(
            "You are a senior data profiler. Return JSON with semantic_meanings, join_keys and quality_notes.",
            json.dumps(llm_payload, default=str),
            enrichment,
        )
        profile["semantic_meanings"] = llm_result.get("semantic_meanings", enrichment["semantic_meanings"])
        profile["join_keys"] = llm_result.get("join_keys", enrichment["join_keys"])
        profile["quality_notes"] = llm_result.get("quality_notes", enrichment["quality_notes"])
        if not cached:
            set_cached_result(key, "profiles", profile, {"task": task_description})
        stamp = pd.Timestamp.utcnow().strftime("%Y%m%dT%H%M%SZ")
        path = PROFILES_DIR / f"profile_{run_id[:8]}_{stamp}.json"
        path.write_text(json.dumps(profile, indent=2, default=str), encoding="utf-8")
        trace.set_output(profile_path=str(path), cache_hit=bool(cached)).complete()
        audit.log("profiler", "complete", profile_path=str(path), cache_hit=bool(cached))
        return str(path)
    except Exception as exc:
        trace.fail(str(exc)); audit.log("profiler", "failed", error=str(exc)); raise


def profile_dataset(file_path: str, run_id: str, task_description: str) -> str:
    return profile_multiple_datasets([file_path], run_id, task_description)
