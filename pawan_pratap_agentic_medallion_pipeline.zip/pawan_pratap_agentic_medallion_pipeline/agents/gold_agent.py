from __future__ import annotations

from pathlib import Path
import pandas as pd
from core.audit import AuditLogger
from core.config import GOLD_DIR
from core.observability import AgentTrace


def _common_keys(frames: list[pd.DataFrame]) -> list[str]:
    common = set(frames[0].columns)
    for frame in frames[1:]:
        common &= set(frame.columns)
    return [c for c in common if not c.startswith("_")]


def execute_gold(silver_files: list[str], sttm_path: str, business_intent: str, run_id: str, task_description: str) -> list[str]:
    trace = AgentTrace("gold", run_id).set_input(silver_files=silver_files, sttm_path=sttm_path, business_intent=business_intent)
    audit = AuditLogger(run_id)
    out_dir = GOLD_DIR / run_id[:8]
    out_dir.mkdir(parents=True, exist_ok=True)
    try:
        frames = [pd.read_parquet(p) for p in silver_files]
        names = [Path(p).stem for p in silver_files]
        outputs = []
        if frames:
            joined = frames[0].copy()
            for idx, frame in enumerate(frames[1:], start=1):
                keys = [k for k in set(joined.columns) & set(frame.columns) if not k.startswith("_")]
                keys = [k for k in keys if joined[k].is_unique or frame[k].is_unique] or keys[:1]
                if keys:
                    joined = joined.merge(frame, on=keys, how="left", suffixes=("", f"_{idx}"))
            joined_path = out_dir / "gold_joined.parquet"
            joined.to_parquet(joined_path, index=False)
            outputs.append(str(joined_path))

            # Generic analytics summary: choose a low/medium-cardinality dimension and numeric measures.
            candidates = [c for c in joined.columns if not c.startswith("_")]
            dims = [c for c in candidates if joined[c].dtype == "object" or str(joined[c].dtype).startswith("string")]
            nums = [c for c in candidates if pd.api.types.is_numeric_dtype(joined[c])]
            if dims and nums:
                dim = min(dims, key=lambda c: abs(joined[c].nunique(dropna=True) - 8))
                agg = joined.groupby(dim, dropna=False)[nums].agg(["sum", "mean"]).reset_index()
                agg.columns = [dim] + [f"{a}_{b}" for a, b in agg.columns.tolist()[1:]]
                summary_path = out_dir / "gold_summary.parquet"
                agg.to_parquet(summary_path, index=False)
                outputs.append(str(summary_path))
            elif nums:
                summary = pd.DataFrame({"metric": nums, "sum": [joined[n].sum() for n in nums], "mean": [joined[n].mean() for n in nums]})
                summary_path = out_dir / "gold_summary.parquet"
                summary.to_parquet(summary_path, index=False)
                outputs.append(str(summary_path))
        trace.set_output(outputs=outputs).complete()
        audit.log("gold_agent", "complete", outputs=outputs, intent=business_intent)
        return outputs
    except Exception as exc:
        trace.fail(str(exc)); audit.log("gold_agent", "failed", error=str(exc)); raise
