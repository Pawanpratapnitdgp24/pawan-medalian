from __future__ import annotations

import json
import re
from typing import Any

import httpx

from core.config import (
    ANTHROPIC_API_KEY, ANTHROPIC_BASE_URL, ANTHROPIC_MODEL,
    GEMINI_MODEL, GOOGLE_API_KEY,
    GITHUB_BASE_URL, GITHUB_MODEL, GITHUB_TOKEN,
    GROQ_API_KEY, GROQ_BASE_URL, GROQ_MODEL,
    LLM_MAX_TOKENS, LLM_TIMEOUT_SECONDS,
    OPENAI_API_KEY, OPENAI_BASE_URL, OPENAI_MODEL,
    detect_provider,
)


class LLMClient:
    """Small provider-neutral JSON/text client.  Falls back to deterministic code when no key exists."""

    def __init__(self):
        self.provider = detect_provider()

    @property
    def enabled(self) -> bool:
        return bool(self.provider)

    def _openai_payload(self, system: str, user: str) -> dict:
        return {
            "model": self._model(),
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
            "temperature": 0,
            "max_tokens": LLM_MAX_TOKENS,
        }

    def _model(self) -> str:
        return {
            "openai": OPENAI_MODEL,
            "groq": GROQ_MODEL,
            "github": GITHUB_MODEL,
            "anthropic": ANTHROPIC_MODEL,
            "gemini": GEMINI_MODEL,
        }[self.provider]

    def _openai_endpoint(self):
        if self.provider == "openai":
            return OPENAI_BASE_URL.rstrip("/") + "/chat/completions", OPENAI_API_KEY
        if self.provider == "groq":
            return GROQ_BASE_URL.rstrip("/") + "/chat/completions", GROQ_API_KEY
        return GITHUB_BASE_URL.rstrip("/") + "/chat/completions", GITHUB_TOKEN

    def complete(self, system: str, user: str) -> str:
        if self.provider in {"openai", "groq", "github"}:
            url, key = self._openai_endpoint()
            response = httpx.post(
                url,
                headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                json=self._openai_payload(system, user),
                timeout=LLM_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
            body = response.json()
            return body["choices"][0]["message"]["content"]

        if self.provider == "anthropic":
            url = ANTHROPIC_BASE_URL.rstrip("/") + "/v1/messages"
            response = httpx.post(
                url,
                headers={
                    "x-api-key": ANTHROPIC_API_KEY,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": ANTHROPIC_MODEL,
                    "max_tokens": LLM_MAX_TOKENS,
                    "temperature": 0,
                    "system": system,
                    "messages": [{"role": "user", "content": user}],
                },
                timeout=LLM_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
            blocks = response.json().get("content", [])
            return "\n".join(block.get("text", "") for block in blocks if block.get("type") == "text")

        if self.provider == "gemini":
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_MODEL}:generateContent"
            response = httpx.post(
                url,
                params={"key": GOOGLE_API_KEY},
                json={
                    "systemInstruction": {"parts": [{"text": system}]},
                    "contents": [{"role": "user", "parts": [{"text": user}]}],
                    "generationConfig": {"temperature": 0, "maxOutputTokens": LLM_MAX_TOKENS},
                },
                timeout=LLM_TIMEOUT_SECONDS,
            )
            response.raise_for_status()
            candidates = response.json().get("candidates", [])
            return candidates[0]["content"]["parts"][0]["text"] if candidates else ""
        raise RuntimeError(f"Unsupported LLM provider: {self.provider}")

    def json(self, system: str, user: str, fallback: Any):
        if not self.enabled:
            return fallback
        try:
            content = self.complete(system, user).strip()
            match = re.search(r"\{.*\}|\[.*\]", content, flags=re.S)
            if not match:
                return fallback
            return json.loads(match.group(0))
        except Exception:
            return fallback
