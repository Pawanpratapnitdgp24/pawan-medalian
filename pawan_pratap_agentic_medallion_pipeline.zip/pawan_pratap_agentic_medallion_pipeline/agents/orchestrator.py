from __future__ import annotations

import uuid
from pathlib import Path
from core.audit import AuditLogger
from core.data_quality import enforce_quality_gate, run_quality_checks, save_quality_report
from core.metrics import MemoryTracker
from core.memory import remember
from core.notifications import send_report_email
from core.run_store import save_state
from core.state import PipelineState
from agents.profiler import profile_multiple_datasets
from agents.sttm_generator import generate_bronze_sttm, generate_silver_sttm, generate_gold_sttm
from agents.bronze_agent import execute_bronze
from agents.silver_agent import execute_silver
from agents.gold_agent import execute_gold
from agents.reporter import generate_report


def new_run(business_intent: str, uploaded_files: list[str]) -> PipelineState:
    state = PipelineState(run_id=str(uuid.uuid4()), business_intent=business_intent, uploaded_files=uploaded_files, status="running")
    save_state(state)
    return state


def _quality(paths: list[str], layer: str, state: PipelineState):
    for path in paths:
        import pandas as pd
        report = run_quality_checks(pd.read_parquet(path), Path(path).stem, layer)
        save_quality_report(report, state.run_id)
        AuditLogger(state.run_id).log("quality", "gate", layer=layer, report=report)
        enforce_quality_gate(report, state.run_id)


def run_until_bronze_sttm(state: PipelineState) -> PipelineState:
    state.phase = "bronze_sttm"
    try:
        with MemoryTracker(state.run_id, "profiler"):
            state.profile_path = profile_multiple_datasets(state.uploaded_files, state.run_id, state.business_intent)
        with MemoryTracker(state.run_id, "sttm_bronze"):
            state.sttm_bronze_path = generate_bronze_sttm(state.profile_path, state.run_id, state.business_intent)
        state.status = "awaiting_bronze_approval"
        save_state(state)
        return state
    except Exception as exc:
        state.status="failed"; state.error=str(exc); state.failed_phase=state.phase; save_state(state); raise


def run_bronze_to_silver_sttm(state: PipelineState) -> PipelineState:
    if not state.bronze_sttm_approved: raise ValueError("Bronze STTM must be approved first.")
    state.phase = "silver_sttm"
    try:
        with MemoryTracker(state.run_id, "bronze"):
            state.bronze_output_paths = execute_bronze(state.uploaded_files, state.sttm_bronze_path, state.run_id, state.business_intent)
        _quality(state.bronze_output_paths, "bronze", state)
        with MemoryTracker(state.run_id, "sttm_silver"):
            state.sttm_silver_path = generate_silver_sttm(state.bronze_output_paths, state.sttm_bronze_path, state.run_id, state.business_intent)
        state.status = "awaiting_silver_approval"
        save_state(state)
        return state
    except Exception as exc:
        state.status="failed"; state.error=str(exc); state.failed_phase=state.phase; save_state(state); raise


def run_silver_to_gold_sttm(state: PipelineState) -> PipelineState:
    if not state.silver_sttm_approved: raise ValueError("Silver STTM must be approved first.")
    state.phase = "gold_sttm"
    try:
        with MemoryTracker(state.run_id, "silver"):
            state.silver_output_paths = execute_silver(state.bronze_output_paths, state.sttm_silver_path, state.run_id, state.business_intent)
        _quality(state.silver_output_paths, "silver", state)
        with MemoryTracker(state.run_id, "sttm_gold"):
            state.sttm_gold_path = generate_gold_sttm(state.silver_output_paths, state.sttm_silver_path, state.business_intent, state.run_id, state.business_intent)
        state.status = "awaiting_gold_approval"
        save_state(state)
        return state
    except Exception as exc:
        state.status="failed"; state.error=str(exc); state.failed_phase=state.phase; save_state(state); raise


def run_gold_and_report(state: PipelineState) -> PipelineState:
    if not state.gold_sttm_approved: raise ValueError("Gold STTM must be approved first.")
    state.phase = "report"
    try:
        with MemoryTracker(state.run_id, "gold"):
            state.gold_output_paths = execute_gold(state.silver_output_paths, state.sttm_gold_path, state.business_intent, state.run_id, state.business_intent)
        _quality(state.gold_output_paths, "gold", state)
        with MemoryTracker(state.run_id, "reporter"):
            state.report_path = generate_report(state.gold_output_paths, state.business_intent, state.run_id)
        state.status = "completed"
        remember(state.run_id, state.business_intent, {"report_path": state.report_path})
        try: send_report_email(f"Pawan Pratap report ready — {state.run_id[:8]}", Path(state.report_path).read_text(encoding="utf-8"))
        except Exception: pass
        save_state(state)
        return state
    except Exception as exc:
        state.status="failed"; state.error=str(exc); state.failed_phase=state.phase; save_state(state); raise
