"""Agent implementations for the Pawan Pratap medallion pipeline."""
