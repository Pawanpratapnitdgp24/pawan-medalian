# Pawan Pratap deployment checklist

- [ ] Push the repository to GitHub.
- [ ] Never commit `.env` or API keys.
- [ ] Confirm `app/streamlit_app.py` is the Streamlit entrypoint.
- [ ] Add provider secrets in Streamlit Cloud, or leave them blank for demo mode.
- [ ] Run `pip install -r requirements.txt` locally.
- [ ] Run `python -m compileall app agents core api.py`.
- [ ] Run `pytest -q`.
- [ ] Test the three CSVs in `sample_data/`.
- [ ] Approve each STTM gate and verify the report and audit trail.
