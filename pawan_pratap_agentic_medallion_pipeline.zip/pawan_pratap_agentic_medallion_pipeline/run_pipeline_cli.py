from __future__ import annotations

import argparse
from pathlib import Path

from agents.orchestrator import new_run, run_until_bronze_sttm, run_bronze_to_silver_sttm, run_silver_to_gold_sttm, run_gold_and_report


def main():
    parser = argparse.ArgumentParser(description="Run Pawan Pratap's agentic medallion pipeline from the CLI.")
    parser.add_argument("--files", nargs="+", required=True, help="Input CSV files")
    parser.add_argument("--question", required=True, help="Business question")
    args = parser.parse_args()
    files = [str(Path(p).resolve()) for p in args.files]
    state = new_run(args.question, files)
    run_until_bronze_sttm(state); state.bronze_sttm_approved = True
    run_bronze_to_silver_sttm(state); state.silver_sttm_approved = True
    run_silver_to_gold_sttm(state); state.gold_sttm_approved = True
    run_gold_and_report(state)
    print(state.report_path)


if __name__ == "__main__":
    main()
