import pytest
pytest.importorskip("pyarrow")
from pathlib import Path
from agents.bronze_agent import execute_bronze
from agents.sttm_generator import generate_bronze_sttm
from agents.profiler import profile_multiple_datasets


def test_bronze_roundtrip(tmp_path):
    root = Path(__file__).resolve().parents[1]
    files = [str(root / "sample_data" / "sales_data.csv")]
    run_id = "12345678-abcdef"
    profile = profile_multiple_datasets(files, run_id, "test sales")
    sttm = generate_bronze_sttm(profile, run_id, "test sales")
    outputs = execute_bronze(files, sttm, run_id, "test sales")
    assert outputs and Path(outputs[0]).exists()
