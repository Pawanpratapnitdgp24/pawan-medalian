from pathlib import Path
import pandas as pd
from agents.profiler import compute_profile
from agents.sttm_generator import _bronze_rules


def test_sttm_preserves_columns():
    root = Path(__file__).resolve().parents[1]
    path = str(root / "sample_data" / "sales_data.csv")
    rules = _bronze_rules([path])
    df = pd.read_csv(path)
    assert {r["source_column"] for r in rules} == set(df.columns)
