import pytest
pytest.importorskip("pyarrow")
from pathlib import Path
from agents.bronze_agent import execute_bronze
from agents.silver_agent import execute_silver
from agents.profiler import profile_multiple_datasets
from agents.sttm_generator import generate_bronze_sttm, generate_silver_sttm


def test_silver_roundtrip():
    root = Path(__file__).resolve().parents[1]
    files = [str(root / "sample_data" / "sales_data.csv")]
    run_id = "22345678-abcdef"
    p = profile_multiple_datasets(files, run_id, "test")
    b = generate_bronze_sttm(p, run_id, "test")
    bo = execute_bronze(files, b, run_id, "test")
    s = generate_silver_sttm(bo, b, run_id, "test")
    so = execute_silver(bo, s, run_id, "test")
    assert so and Path(so[0]).exists()
