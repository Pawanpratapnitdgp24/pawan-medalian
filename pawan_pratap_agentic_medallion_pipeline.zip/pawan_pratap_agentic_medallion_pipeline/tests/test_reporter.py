import pytest
pytest.importorskip("duckdb")
pytest.importorskip("pyarrow")
from pathlib import Path
from agents.reporter import _safe_sql, _table_name


def test_sql_guard():
    assert _safe_sql("SELECT 1") == "SELECT 1"
    with pytest.raises(ValueError):
        _safe_sql("DROP TABLE demo")


def test_table_name():
    assert _table_name("foo-bar.parquet") == "foo_bar"
