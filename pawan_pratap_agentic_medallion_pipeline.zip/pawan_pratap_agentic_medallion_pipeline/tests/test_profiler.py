from pathlib import Path
from agents.profiler import inspect_files, compute_profile

ROOT = Path(__file__).resolve().parents[1]


def test_profiler_sample():
    files = [str(ROOT / "sample_data" / "sales_data.csv"), str(ROOT / "sample_data" / "products.csv")]
    report = inspect_files(files)
    assert len(report) == 2
    profile = compute_profile(files)
    assert "join_candidates" in profile
    assert "product_id" in profile["join_candidates"]
