from pathlib import Path
import pandas as pd
from core.custom_transforms import apply_custom_expression, apply_regex_replace
from core.data_quality import run_quality_checks
from core.lineage import build_mermaid_diagram
from core.state import PipelineState


def test_custom_expression_safe():
    df = pd.DataFrame({"qty": [2, 3], "price": [10, 5]})
    out = apply_custom_expression(df, "qty * price")
    assert out.tolist() == [20, 15]


def test_regex():
    df = pd.DataFrame({"x": [" a  b ", "c"]})
    out = apply_regex_replace(df["x"], r"\s+", " ")
    assert out.iloc[0] == " a b "


def test_quality_and_lineage():
    df = pd.DataFrame({"a": [1, 2, 2], "b": ["x", "y", "z"]})
    report = run_quality_checks(df, "demo", "bronze")
    assert report["score"] > 0
    state = PipelineState("abc")
    assert "Landing CSVs" in build_mermaid_diagram(state)
