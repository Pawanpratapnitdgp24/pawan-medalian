import pytest
pytest.importorskip("pyarrow")
from pathlib import Path
from agents.gold_agent import execute_gold
from agents.bronze_agent import execute_bronze
from agents.silver_agent import execute_silver
from agents.profiler import profile_multiple_datasets
from agents.sttm_generator import generate_bronze_sttm, generate_silver_sttm, generate_gold_sttm


def test_gold_roundtrip():
    root = Path(__file__).resolve().parents[1]
    files = [str(root / "sample_data" / "sales_data.csv"), str(root / "sample_data" / "products.csv")]
    run_id = "32345678-abcdef"
    p = profile_multiple_datasets(files, run_id, "revenue")
    b = generate_bronze_sttm(p, run_id, "revenue")
    bo = execute_bronze(files, b, run_id, "revenue")
    s = generate_silver_sttm(bo, b, run_id, "revenue")
    so = execute_silver(bo, s, run_id, "revenue")
    g = generate_gold_sttm(so, s, "revenue", run_id, "revenue")
    go = execute_gold(so, g, "revenue", run_id, "revenue")
    assert len(go) >= 1
