from core.audit import AuditLogger

def test_audit_roundtrip(tmp_path):
    logger = AuditLogger("audit-test-1234")
    logger.log("tester", "hello", value=1)
    logs = logger.get_logs()
    assert logs[-1]["action"] == "hello"
