from __future__ import annotations

from pathlib import Path
import pandas as pd


def export_gold_files(gold_files: list[str], dsn: str, schema: str = "gold") -> list[str]:
    """Optional Gold->PostgreSQL exporter. Imports SQLAlchemy only when called."""
    from sqlalchemy import create_engine
    engine = create_engine(dsn)
    exported = []
    for file in gold_files:
        df = pd.read_parquet(file)
        table = Path(file).stem.replace("-", "_")
        df.to_sql(table, engine, schema=schema, if_exists="replace", index=False)
        exported.append(f"{schema}.{table}")
    return exported
