# Deployment guide — Pawan Pratap Agentic Medallion Pipeline

## 1. GitHub

Create a new repository and push this entire folder.

```bash
git init
git add .
git commit -m "Initial Pawan Pratap agentic medallion pipeline"
git branch -M main
git remote add origin https://github.com/<YOUR_GITHUB_USERNAME>/pawan-pratap-agentic-medallion-pipeline.git
git push -u origin main
```

## 2. Streamlit Community Cloud

Use `app/streamlit_app.py` as the entrypoint.

Secrets can be entered in Streamlit Cloud instead of committing `.env`.

Recommended secrets:

```toml
LLM_PROVIDER = "groq"
GROQ_API_KEY = "your-key"
GROQ_MODEL = "your-current-model"
```

For a no-key demo, leave the provider blank. The application automatically uses its deterministic mode.

## 3. Local run

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
streamlit run app/streamlit_app.py
```

## 4. Docker

```bash
cp .env.example .env
docker compose up --build
```

## 5. API

```bash
uvicorn api:app --host 0.0.0.0 --port 8000
```

Then visit `http://localhost:8000/docs`.

## 6. CLI

```bash
python run_pipeline_cli.py \
  --files sample_data/sales_data.csv sample_data/products.csv sample_data/stores.csv \
  --question "Which regions and categories drive revenue?"
```
